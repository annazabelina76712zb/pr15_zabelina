package com.example.prakt15_zykova_andrst

import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Email
import android.view.View
import android.widget.EditText

class Login : AppCompatActivity() {
    lateinit var email: EditText
    lateinit var password: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        email = findViewById(R.id.email)
        password = findViewById(R.id.password)

        fun signin(view: View){
            if (email.text.toString().isNotEmpty() && password.text.toString().isNotEmpty()){

            }
            else{
                val alert = AlertDialog.Builder(this) //создание окна
                    .setTitle("Ошибка")//заголовок
                    .setMessage("У вас есть незаполненные поля") //сообщение
                    .setPositiveButton("Ок", null) //добавление кнопки
                    .create()
                    .show() //вывод на экран
            }
        }
    }
}